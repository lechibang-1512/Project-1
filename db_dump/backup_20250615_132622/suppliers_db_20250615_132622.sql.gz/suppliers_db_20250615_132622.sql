/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.2-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: suppliers_db
-- ------------------------------------------------------
-- Server version	11.8.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Current Database: `suppliers_db`
--

/*!40000 DROP DATABASE IF EXISTS `suppliers_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `suppliers_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `suppliers_db`;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_position` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stores main supplier company details';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `suppliers` (`id`, `name`, `category`, `contact_person`, `contact_position`, `contact_email`, `email`, `phone`, `website`, `address`, `notes`, `is_active`, `created_at`) VALUES (1,'TechCorp Solutions',NULL,'John Smith',NULL,NULL,'john@techcorp.com','+1-555-0101',NULL,'123 Tech Street, Silicon Valley, CA 94000',NULL,1,'2025-06-14 12:39:04'),
(2,'Industrial Parts Ltd',NULL,'Sarah Johnson',NULL,NULL,'sarah@industrialparts.com','+1-555-0102',NULL,'456 Industry Blvd, Detroit, MI 48000',NULL,1,'2025-06-14 12:39:04'),
(3,'Global Electronics',NULL,'Mike Chen',NULL,NULL,'mike@globalelectronics.com','+1-555-0103',NULL,'789 Electronics Ave, Austin, TX 73000',NULL,1,'2025-06-14 12:39:04'),
(4,'Precision Tools Inc',NULL,'Lisa Rodriguez',NULL,NULL,'lisa@precisiontools.com','+1-555-0104',NULL,'321 Tools Drive, Cleveland, OH 44000',NULL,1,'2025-06-14 12:39:04'),
(5,'Green Supply Co',NULL,'David Wilson',NULL,NULL,'david@greensupply.com','+1-555-0105',NULL,'654 Green Lane, Portland, OR 97000',NULL,1,'2025-06-14 12:39:04'),
(6,'Quality Materials',NULL,'Emma Thompson',NULL,NULL,'emma@qualitymaterials.com','+1-555-0106',NULL,'987 Quality Road, Denver, CO 80000',NULL,0,'2025-06-14 12:39:04'),
(7,'Fast Logistics',NULL,'Robert Brown',NULL,NULL,'robert@fastlogistics.com','+1-555-0107',NULL,'147 Speed Highway, Phoenix, AZ 85000',NULL,1,'2025-06-14 12:39:04'),
(8,'Reliable Components',NULL,'Jennifer Davis',NULL,NULL,'jennifer@reliablecomponents.com','+1-555-0108',NULL,'258 Reliable Street, Seattle, WA 98000',NULL,1,'2025-06-14 12:39:04'),
(49,'Apex Tech Solutions','CPU, GPU, Motherboard, RAM, PSU, Case, Cooling, Storage','An Nguyen','Sales Director','an.nguyen@apextech.vn','sales@apextech.vn','0901234567','https://apextech.vn','15 Tran Hung Dao, Hoan Kiem, Hanoi','Primary distributor for major brands. Bulk discounts available.',0,'2024-05-20 03:00:00'),
(50,'Global Chip Distribution','CPU, GPU, RAM, Storage','John Smith','Global Accounts','j.smith@globalchip.com','contact@globalchip.com','+1-408-555-0101','https://globalchip.com','2100 Logic Lane, San Jose, CA, USA','International supplier, handles large B2B orders only. Minimum order $10,000.',1,'2023-11-10 07:20:00'),
(51,'Hanoi Computer World','CPU, GPU, Motherboard, RAM, PSU, Case, Cooling, Storage, Peripherals','Tran Van Bach','Store Manager','bach.tv@hanoicw.com.vn','support@hanoicw.com.vn','0988123123','https://hanoicw.com.vn','55 Thai Ha, Dong Da, Hanoi','Leading local retailer for all PC components and peripherals.',1,'2024-01-15 02:30:00'),
(52,'PC Parts Pro','Motherboard, RAM, PSU, Case','Emily Carter','B2B Manager','emily.c@pcpartspro.net','sales@pcpartspro.net','0977654321','https://pcpartspro.net','789 Component Ave, Industry City','Focuses on core components for system builders.',1,'2024-02-28 04:00:00'),
(53,'Saigon Tech Hub','GPU, RAM, Storage, Peripherals','Le Thi Mai','Sales Representative','mai.le@saigontech.vn','info@saigontech.vn','0915888999','https://saigontech.vn','101 Nguyen Hue, District 1, Ho Chi Minh City','Strong focus on gaming components and high-end peripherals.',1,'2024-03-12 09:45:00'),
(54,'CPU Core','CPU','Michael Chen','Sourcing Specialist','m.chen@cpucore.io','sourcing@cpucore.io','+886-2-5555-0188','https://cpucore.io','Hsinchu Science Park, Hsinchu, Taiwan','Specializes in bulk trays of Intel and AMD CPUs.',1,'2024-06-05 11:00:00'),
(55,'GPU Kings','GPU','David Lee','Product Manager','david.l@gpukings.com','support@gpukings.com','0905111222','https://gpukings.com','Akihabara, Tokyo, Japan','Imports and distributes high-end and rare GPUs.',1,'2023-10-03 05:10:00'),
(56,'Board Builders Inc.','Motherboard','Sophia Rodriguez','Lead Engineer','sophia.r@boardbuilders.com','tech@boardbuilders.com','+1-512-555-0155','https://boardbuilders.com','Austin, TX, USA','OEM manufacturer of custom motherboards. No retail.',1,'2024-04-19 08:00:00'),
(57,'Memory Module Masters','RAM','Ben Carter','Sales Rep','ben@memmasters.net','sales@memmasters.net','0933445566','https://memmasters.net','Shenzhen, Guangdong, China','High-volume RAM module supplier.',1,'2023-08-25 02:55:00'),
(58,'VoltVault Power','PSU','Frank Miller','Quality Assurance','frank.m@voltvault.com','qa@voltvault.com','0987000111','https://voltvault.com','Hamburg, Germany','Supplier of high-efficiency, certified power supply units.',1,'2024-05-01 06:30:00'),
(59,'Chassis Crafters','Case','Chloe Garcia','Designer','chloe.g@chassiscrafters.dev','info@chassiscrafters.dev','0911223344','https://chassiscrafters.dev','Los Angeles, CA, USA','Boutique PC case designer and manufacturer.',1,'2024-07-01 04:15:00'),
(60,'Arctic Airflow','Cooling','Olaf Gustafsson','R&D Head','olaf.g@arcticairflow.se','contact@arcticairflow.se','+46-8-555-0123','https://arcticairflow.se','Stockholm, Sweden','Specializes in high-performance CPU coolers and case fans.',1,'2023-09-14 03:40:00'),
(61,'DataDrive Direct','Storage','Kenji Tanaka','Director of Ops','k.tanaka@datadrive.jp','orders@datadrive.jp','+81-3-5555-0199','https://datadrive.jp','Shibuya, Tokyo, Japan','Wholesale supplier of SSDs and NVMe drives.',1,'2024-02-17 12:00:00'),
(62,'Ergo-Clicks','Peripherals','Laura Schmidt','Marketing','laura.s@ergo-clicks.de','info@ergo-clicks.de','0955667788','https://ergo-clicks.de','Berlin, Germany','Focus on ergonomic mice and keyboards.',1,'2023-12-22 09:20:00'),
(63,'Visionary Displays','Monitors','Rachel Adams','Sales Executive','r.adams@visionary.com','sales@visionary.com','0922334455','https://visionary.com','Seoul, South Korea','Supplier of professional-grade 4K and OLED monitors.',1,'2024-06-11 07:00:00'),
(64,'Danang IT Surplus','RAM, Storage, Used GPUs','Pham Van Dong','Owner','dong.pham@danangit.vn','contact@danangit.vn','0944556677','https://danangit.vn','3 Le Duan, Hai Chau, Da Nang','Sells new old stock and tested used components.',1,'2023-05-30 10:10:00'),
(65,'Power & Case Co.','PSU, Case','Robert Brown','Partner','rob.b@powercase.com','info@powercase.com','0966778899','https://powercase.com','Manchester, UK','Small supplier focusing on budget builds.',1,'2024-08-01 03:00:00'),
(66,'Old Components Ltd.','Motherboard, RAM','N/A','N/A','contact-1@old-components.example.com','main-1@old-components.example.com','N/A','N/A','N/A','Ceased trading in 2023. Do not contact.',0,'2021-04-11 17:00:00'),
(67,'Connector King','Cables, Adapters','Henry Wu','Manager','henry.w@connectorking.net','orders@connectorking.net','0988990011','https://connectorking.net','Guangzhou, China','Sells all types of internal and external PC cables.',1,'2023-07-20 04:30:00'),
(68,'Defunct Devices','CPU, GPU','N/A','N/A','contact-2@defunct-devices.example.com','main-2@defunct-devices.example.com','N/A','N/A','N/A','Went into administration. All assets sold.',0,'2022-10-04 17:00:00');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'suppliers_db'
--

--
-- Dumping routines for database 'suppliers_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-06-15 13:26:22
