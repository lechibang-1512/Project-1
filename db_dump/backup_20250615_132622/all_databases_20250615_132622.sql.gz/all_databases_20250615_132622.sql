/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.2-MariaDB, for Linux (x86_64)
--
-- Host: localhost    Database: master_specs_db
-- ------------------------------------------------------
-- Server version	11.8.2-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Current Database: `master_specs_db`
--

/*!40000 DROP DATABASE IF EXISTS `master_specs_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `master_specs_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `master_specs_db`;

--
-- Table structure for table `case_specs`
--

DROP TABLE IF EXISTS `case_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `case_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  `part_number` varchar(100) NOT NULL,
  `case_type` varchar(50) DEFAULT NULL COMMENT 'e.g., Mid-Tower, Full-Tower, Mini-ITX',
  `color` varchar(50) DEFAULT NULL,
  `material` varchar(255) DEFAULT NULL,
  `window_material` varchar(100) DEFAULT NULL COMMENT 'e.g., Tempered Glass, Acrylic, None',
  `dimensions_mm` varchar(100) DEFAULT NULL COMMENT 'Format: L x W x H mm',
  `weight_kg` decimal(5,2) DEFAULT NULL,
  `motherboard_support` varchar(255) DEFAULT NULL COMMENT 'e.g., Mini-ITX, Micro-ATX, ATX, E-ATX',
  `psu_form_factor_support` varchar(50) DEFAULT 'ATX',
  `max_gpu_length_mm` smallint(5) unsigned DEFAULT NULL,
  `max_psu_length_mm` smallint(5) unsigned DEFAULT NULL,
  `max_cpu_cooler_height_mm` smallint(5) unsigned DEFAULT NULL,
  `expansion_slots_horizontal` tinyint(3) unsigned DEFAULT 0,
  `expansion_slots_vertical` tinyint(3) unsigned DEFAULT 0,
  `drive_bays_3_5_inch` tinyint(3) unsigned DEFAULT 0,
  `drive_bays_2_5_inch` tinyint(3) unsigned DEFAULT 0,
  `front_panel_io` text DEFAULT NULL,
  `fan_support` text DEFAULT NULL COMMENT 'Detailed breakdown of fan locations and sizes',
  `radiator_support` text DEFAULT NULL COMMENT 'Detailed breakdown of radiator locations and sizes',
  `included_fans` text DEFAULT NULL,
  `dust_filters` text DEFAULT NULL COMMENT 'Location of dust filters, e.g., Front, Top, PSU',
  `cable_routing_space_mm` smallint(5) unsigned DEFAULT NULL,
  `vertical_gpu_mount` tinyint(1) DEFAULT 0,
  `warranty_years` tinyint(3) unsigned DEFAULT NULL,
  `last_updated` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `stock_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `part_number_uniq` (`part_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `case_specs`
--

LOCK TABLES `case_specs` WRITE;
/*!40000 ALTER TABLE `case_specs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `case_specs` (`id`, `manufacturer`, `model`, `part_number`, `case_type`, `color`, `material`, `window_material`, `dimensions_mm`, `weight_kg`, `motherboard_support`, `psu_form_factor_support`, `max_gpu_length_mm`, `max_psu_length_mm`, `max_cpu_cooler_height_mm`, `expansion_slots_horizontal`, `expansion_slots_vertical`, `drive_bays_3_5_inch`, `drive_bays_2_5_inch`, `front_panel_io`, `fan_support`, `radiator_support`, `included_fans`, `dust_filters`, `cable_routing_space_mm`, `vertical_gpu_mount`, `warranty_years`, `last_updated`, `stock_quantity`) VALUES (1,'Corsair','4000D Airflow','CC-9011200-WW','Mid-Tower','Black','Steel, Plastic, Tempered Glass','Tempered Glass','453mm x 230mm x 466mm',9.15,'Mini-ITX, Micro-ATX, ATX, E-ATX (305mm x 277mm)','ATX',360,220,170,7,2,2,4,'(1x) USB 3.1 Type C, (1x) USB 3.0, (1x) Audio in/out','Front: 3x 120mm or 2x 140mm; Top: 2x 120mm or 2x 140mm; Rear: 1x 120mm','Front: 360mm, 280mm, 240mm; Top: 280mm, 240mm; Rear: 120mm','1x 120mm AirGuide (Front), 1x 120mm AirGuide (Rear)','Front, Top, PSU',29,1,2,'2025-06-15 02:06:46',12);
/*!40000 ALTER TABLE `case_specs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `cpu_specs`
--

DROP TABLE IF EXISTS `cpu_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cpu_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `product_collection` varchar(255) DEFAULT NULL,
  `code_name` varchar(255) DEFAULT NULL,
  `vertical_segment` varchar(50) DEFAULT NULL,
  `processor_number` varchar(50) DEFAULT NULL,
  `lithography` varchar(50) DEFAULT NULL,
  `recommended_customer_price_min` decimal(10,2) DEFAULT NULL,
  `recommended_customer_price_max` decimal(10,2) DEFAULT NULL,
  `total_cores` int(11) DEFAULT NULL,
  `performance_cores` int(11) DEFAULT NULL,
  `efficient_cores` int(11) DEFAULT NULL,
  `total_threads` int(11) DEFAULT NULL,
  `max_turbo_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `turbo_boost_max_3_0_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `performance_core_max_turbo_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `efficient_core_max_turbo_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `performance_core_base_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `efficient_core_base_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `cache_mb` int(11) DEFAULT NULL,
  `total_l2_cache_mb` int(11) DEFAULT NULL,
  `processor_base_power_w` int(11) DEFAULT NULL,
  `maximum_turbo_power_w` int(11) DEFAULT NULL,
  `launch_date` varchar(10) DEFAULT NULL,
  `embedded_options_available` tinyint(1) DEFAULT NULL,
  `max_memory_size_gb` int(11) DEFAULT NULL,
  `memory_types` varchar(255) DEFAULT NULL,
  `max_memory_channels` int(11) DEFAULT NULL,
  `max_memory_bandwidth_gb_s` decimal(5,1) DEFAULT NULL,
  `ecc_memory_supported` tinyint(1) DEFAULT NULL,
  `gpu_name` varchar(255) DEFAULT NULL,
  `graphics_base_frequency_mhz` int(11) DEFAULT NULL,
  `graphics_max_dynamic_frequency_ghz` decimal(4,2) DEFAULT NULL,
  `graphics_output` varchar(255) DEFAULT NULL,
  `execution_units` int(11) DEFAULT NULL,
  `max_resolution_hdmi` varchar(255) DEFAULT NULL,
  `max_resolution_dp` varchar(255) DEFAULT NULL,
  `max_resolution_edp` varchar(255) DEFAULT NULL,
  `directx_support` varchar(10) DEFAULT NULL,
  `opengl_support` varchar(10) DEFAULT NULL,
  `opencl_support` varchar(10) DEFAULT NULL,
  `multi_format_codec_engines` int(11) DEFAULT NULL,
  `intel_quick_sync_video` tinyint(1) DEFAULT NULL,
  `intel_clear_video_hd_technology` tinyint(1) DEFAULT NULL,
  `displays_supported` int(11) DEFAULT NULL,
  `device_id` varchar(20) DEFAULT NULL,
  `dmi_revision` decimal(3,1) DEFAULT NULL,
  `max_dmi_lanes` int(11) DEFAULT NULL,
  `scalability` varchar(10) DEFAULT NULL,
  `pci_express_revision` varchar(20) DEFAULT NULL,
  `pci_express_configurations` varchar(255) DEFAULT NULL,
  `max_pci_express_lanes` int(11) DEFAULT NULL,
  `sockets_supported` varchar(50) DEFAULT NULL,
  `max_cpu_configuration` int(11) DEFAULT NULL,
  `thermal_solution_specification` varchar(50) DEFAULT NULL,
  `tjunction_celsius` int(11) DEFAULT NULL,
  `package_size_mm` varchar(50) DEFAULT NULL,
  `intel_gaussian_neural_accelerator_version` varchar(10) DEFAULT NULL,
  `intel_thread_director` tinyint(1) DEFAULT NULL,
  `intel_dl_boost` tinyint(1) DEFAULT NULL,
  `intel_optane_memory_supported` tinyint(1) DEFAULT NULL,
  `intel_speed_shift_technology` tinyint(1) DEFAULT NULL,
  `intel_turbo_boost_max_technology_3_0` tinyint(1) DEFAULT NULL,
  `intel_turbo_boost_technology_version` varchar(10) DEFAULT NULL,
  `intel_hyper_threading_technology` tinyint(1) DEFAULT NULL,
  `intel_64` tinyint(1) DEFAULT NULL,
  `instruction_set` varchar(10) DEFAULT NULL,
  `instruction_set_extensions` varchar(255) DEFAULT NULL,
  `idle_states` tinyint(1) DEFAULT NULL,
  `enhanced_intel_speedstep_technology` tinyint(1) DEFAULT NULL,
  `thermal_monitoring_technologies` tinyint(1) DEFAULT NULL,
  `intel_volume_management_device_vmd` tinyint(1) DEFAULT NULL,
  `intel_vpro_eligibility` varchar(255) DEFAULT NULL,
  `intel_threat_detection_technology_tdt` tinyint(1) DEFAULT NULL,
  `intel_active_management_technology_amt` tinyint(1) DEFAULT NULL,
  `intel_standard_manageability_ism` tinyint(1) DEFAULT NULL,
  `intel_one_click_recovery` tinyint(1) DEFAULT NULL,
  `intel_hardware_shield_eligibility` tinyint(1) DEFAULT NULL,
  `intel_control_flow_enforcement_technology` tinyint(1) DEFAULT NULL,
  `intel_total_memory_encryption_multi_key` tinyint(1) DEFAULT NULL,
  `intel_total_memory_encryption` tinyint(1) DEFAULT NULL,
  `intel_aes_new_instructions` tinyint(1) DEFAULT NULL,
  `intel_secure_key` tinyint(1) DEFAULT NULL,
  `intel_os_guard` tinyint(1) DEFAULT NULL,
  `intel_trusted_execution_technology` tinyint(1) DEFAULT NULL,
  `execute_disable_bit` tinyint(1) DEFAULT NULL,
  `intel_boot_guard` tinyint(1) DEFAULT NULL,
  `mode_based_execute_control_mbec` tinyint(1) DEFAULT NULL,
  `intel_stable_it_platform_program_sipp` tinyint(1) DEFAULT NULL,
  `intel_virtualization_technology_with_redirect_protection_vt_rp` tinyint(1) DEFAULT NULL,
  `intel_virtualization_technology_vtx` tinyint(1) DEFAULT NULL,
  `intel_virtualization_technology_for_directed_io_vtd` tinyint(1) DEFAULT NULL,
  `intel_vtx_with_extended_page_tables_ept` tinyint(1) DEFAULT NULL,
  `manufacturer` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cpu_specs`
--

LOCK TABLES `cpu_specs` WRITE;
/*!40000 ALTER TABLE `cpu_specs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `cpu_specs` (`id`, `product_collection`, `code_name`, `vertical_segment`, `processor_number`, `lithography`, `recommended_customer_price_min`, `recommended_customer_price_max`, `total_cores`, `performance_cores`, `efficient_cores`, `total_threads`, `max_turbo_frequency_ghz`, `turbo_boost_max_3_0_frequency_ghz`, `performance_core_max_turbo_frequency_ghz`, `efficient_core_max_turbo_frequency_ghz`, `performance_core_base_frequency_ghz`, `efficient_core_base_frequency_ghz`, `cache_mb`, `total_l2_cache_mb`, `processor_base_power_w`, `maximum_turbo_power_w`, `launch_date`, `embedded_options_available`, `max_memory_size_gb`, `memory_types`, `max_memory_channels`, `max_memory_bandwidth_gb_s`, `ecc_memory_supported`, `gpu_name`, `graphics_base_frequency_mhz`, `graphics_max_dynamic_frequency_ghz`, `graphics_output`, `execution_units`, `max_resolution_hdmi`, `max_resolution_dp`, `max_resolution_edp`, `directx_support`, `opengl_support`, `opencl_support`, `multi_format_codec_engines`, `intel_quick_sync_video`, `intel_clear_video_hd_technology`, `displays_supported`, `device_id`, `dmi_revision`, `max_dmi_lanes`, `scalability`, `pci_express_revision`, `pci_express_configurations`, `max_pci_express_lanes`, `sockets_supported`, `max_cpu_configuration`, `thermal_solution_specification`, `tjunction_celsius`, `package_size_mm`, `intel_gaussian_neural_accelerator_version`, `intel_thread_director`, `intel_dl_boost`, `intel_optane_memory_supported`, `intel_speed_shift_technology`, `intel_turbo_boost_max_technology_3_0`, `intel_turbo_boost_technology_version`, `intel_hyper_threading_technology`, `intel_64`, `instruction_set`, `instruction_set_extensions`, `idle_states`, `enhanced_intel_speedstep_technology`, `thermal_monitoring_technologies`, `intel_volume_management_device_vmd`, `intel_vpro_eligibility`, `intel_threat_detection_technology_tdt`, `intel_active_management_technology_amt`, `intel_standard_manageability_ism`, `intel_one_click_recovery`, `intel_hardware_shield_eligibility`, `intel_control_flow_enforcement_technology`, `intel_total_memory_encryption_multi_key`, `intel_total_memory_encryption`, `intel_aes_new_instructions`, `intel_secure_key`, `intel_os_guard`, `intel_trusted_execution_technology`, `execute_disable_bit`, `intel_boot_guard`, `mode_based_execute_control_mbec`, `intel_stable_it_platform_program_sipp`, `intel_virtualization_technology_with_redirect_protection_vt_rp`, `intel_virtualization_technology_vtx`, `intel_virtualization_technology_for_directed_io_vtd`, `intel_vtx_with_extended_page_tables_ept`, `manufacturer`, `stock_quantity`) VALUES (1,'12th Generation Intel® Core™ i7 Processors','Products formerly Alder Lake','Desktop','i7-12700K','Intel 7',450.00,460.00,12,8,4,20,5.00,5.00,4.90,3.80,3.60,2.70,25,12,125,190,'Q4\'21',0,128,'Up to DDR5 4800 MT/s, Up to DDR4 3200 MT/s',2,76.8,1,'Intel® UHD Graphics 770',300,1.50,'eDP 1.4b, DP 1.4a, HDMI 2.1',32,'4096 x 2160 @ 60Hz','7680 x 4320 @ 60Hz','5120 x 3200 @ 120Hz','12','4.5','3.0',2,1,1,4,'0x4680',4.0,8,'1S Only','5.0 and 4.0','Up to 1x16+4, 2x8+4',20,'FCLGA1700',1,'PCG 2020A',100,'45.0 mm x 37.5 mm','3.0',1,1,1,1,1,'2.0',1,1,'64-bit','Intel® SSE4.1, Intel® SSE4.2, Intel® AVX2',1,1,1,1,'Intel vPro® Enterprise',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,'Intel',12),
(2,'8th Generation Intel® Core™ i7 Processors','Products formerly Coffee Lake','Desktop','i7-8700','14 nm',303.00,NULL,6,NULL,NULL,12,4.60,NULL,NULL,NULL,3.20,NULL,12,NULL,65,NULL,'Q4\'17',1,128,'DDR4-2666',2,41.6,0,'Intel® UHD Graphics 630',350,1.20,NULL,NULL,'4096x2304@24Hz','4096x2304@60Hz','4096x2304@60Hz','12','4.5',NULL,NULL,1,1,3,'0x3E92',3.0,NULL,'1S Only','3.0','Up to 1x16, 2x8, 1x8+2x4',16,'FCLGA1151',1,'PCG 2015C (65W)',100,'37.5mm x 37.5mm',NULL,NULL,NULL,1,1,NULL,'2.0',1,1,'64-bit','Intel® SSE4.1, Intel® SSE4.2, Intel® AVX2',1,1,1,NULL,'Intel vPro® Platform',NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,1,1,1,1,1,NULL,1,NULL,1,1,1,'Intel',12),
(3,'12th Generation Intel® Core™ i7 Processors','Products formerly Alder Lake','Desktop','i7-12700F','Intel 7',345.00,355.00,12,8,4,20,4.90,4.90,4.80,3.60,2.10,1.60,25,12,65,180,'Q1\'22',0,128,'Up to DDR5 4800 MT/s, Up to DDR4 3200 MT/s',2,76.8,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,4.0,8,'1S Only','5.0 and 4.0','Up to 1x16+4, 2x8+4',20,'FCLGA1700',1,'PCG 2020C',100,'45.0 mm x 37.5 mm','3.0',1,1,1,1,1,'2.0',1,1,'64-bit','Intel® SSE4.1, Intel® SSE4.2, Intel® AVX2',1,1,1,1,NULL,NULL,NULL,1,NULL,NULL,1,NULL,NULL,1,1,1,NULL,1,1,1,NULL,NULL,1,1,1,'Intel',12);
/*!40000 ALTER TABLE `cpu_specs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `motherboard_specs`
--

DROP TABLE IF EXISTS `motherboard_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `motherboard_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(255) NOT NULL,
  `model` varchar(255) NOT NULL,
  `chipset` varchar(100) DEFAULT NULL,
  `cpu_socket` varchar(100) DEFAULT NULL,
  `supported_processors` text DEFAULT NULL,
  `memory_slots` tinyint(3) unsigned DEFAULT NULL,
  `memory_type` varchar(20) DEFAULT NULL,
  `max_memory_gb` smallint(5) unsigned DEFAULT NULL,
  `supported_memory_speeds_oc` text DEFAULT NULL COMMENT 'Comma-separated overclocked speeds',
  `supported_memory_speeds_jedec` text DEFAULT NULL COMMENT 'Comma-separated JEDEC speeds',
  `onboard_graphics_outputs` text DEFAULT NULL COMMENT 'e.g., 1x HDMI, 1x DisplayPort',
  `expansion_slots` text DEFAULT NULL,
  `storage` text DEFAULT NULL,
  `raid_support` varchar(255) DEFAULT NULL,
  `audio_codec` varchar(255) DEFAULT NULL,
  `lan_controller` varchar(255) DEFAULT NULL,
  `wireless_lan_bluetooth` varchar(255) DEFAULT NULL,
  `rear_usb_ports` text DEFAULT NULL,
  `front_usb_ports` text DEFAULT NULL,
  `internal_io_connectors` text DEFAULT NULL,
  `form_factor` varchar(50) DEFAULT NULL,
  `dimensions_mm` varchar(100) DEFAULT NULL,
  `operating_system_support` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `motherboard_specs`
--

LOCK TABLES `motherboard_specs` WRITE;
/*!40000 ALTER TABLE `motherboard_specs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `motherboard_specs` (`id`, `manufacturer`, `model`, `chipset`, `cpu_socket`, `supported_processors`, `memory_slots`, `memory_type`, `max_memory_gb`, `supported_memory_speeds_oc`, `supported_memory_speeds_jedec`, `onboard_graphics_outputs`, `expansion_slots`, `storage`, `raid_support`, `audio_codec`, `lan_controller`, `wireless_lan_bluetooth`, `rear_usb_ports`, `front_usb_ports`, `internal_io_connectors`, `form_factor`, `dimensions_mm`, `operating_system_support`, `stock_quantity`) VALUES (1,'MSI','B760 GAMING PLUS WIFI','INTEL B760','LGA 1700','Support Intel® Core™ 14th/ 13th/ 12th Gen Processors, Intel® Pentium® Gold and Celeron® Processors',4,'DDR5',256,'6800,6600,6400,6200,6000,5800','5600,5400,5200,5000,4800','1x HDMI™ (Support HDMI™ 2.1 with HDR, max 4K 60Hz), 1x DisplayPort (Support DP 1.4, max 4K 60Hz)','PCI_E1 Gen PCIe 4.0 supports up to x16 (From CPU), PCI_E2 Gen PCIe 3.0 supports up to x1 (From Chipset), PCI_E3 Gen PCIe 4.0 supports up to x4 (From Chipset), PCI_E4 Gen PCIe 3.0 supports up to x1 (From Chipset), PCI_E5 Gen PCIe 3.0 supports up to x1 (From Chipset)','2x M.2 (M.2_1 Source (From CPU) supports up to PCIe 4.0 x4 , supports 22110/2280/2260/2242 devices; M.2_2 Source (From Chipset) supports up to PCIe 4.0 x4 / SATA mode, supports 2280/2260/2242 devices), 4x SATA 6G','Supports RAID 0, RAID 1, RAID 5 and RAID 10 for SATA storage devices','Realtek® ALC897 Codec, 7.1-Channel High Definition Audio, Supports S/PDIF output','Realtek® RTL8125BG 2.5G LAN','Intel® Wi-Fi 6E (Supports MU-MIMO TX/RX, 2.4GHz / 5GHz / 6GHz* (160MHz) up to 2.4Gbps, Supports 802.11 a/b/g/n/ac/ax), Bluetooth® 5.3','4x USB 2.0, 2x USB 10Gbps Type A, 1x USB 10Gbps Type C, Keyboard/Mouse, DisplayPort, HDMI™, 2.5G LAN, Wi-Fi/Bluetooth Antennas, Audio Connectors, S/PDIF-OUT','4x USB 2.0, 2x USB 5Gbps Type A, 1x USB 5Gbps Type C','1x Power Connector(ATX_PWR), 2x Power Connector(CPU_PWR), 1x CPU Fan, 1x Pump Fan, 5x System Fan, 2x Front Panel (JFP), 1x Chassis Intrusion (JCI), 1x Front Audio (JAUD), 1x Printer Port (JLPT), 1x Com Port (JCOM), 2x Addressable V2 RGB LED connector (JARGB_V2), 1x RGB LED connector(JRGB), 1x TPM pin header(Support TPM 2.0), 4x USB 2.0 ports (headers), 2x USB 5Gbps Type A ports (headers), 1x USB 5Gbps Type C ports (header)','ATX','243.84mmx304.8mm','Support for Windows® 11 64-bit, Windows® 10 64-bit',12),
(2,'GIGABYTE','Z390 GAMING X','Intel® Z390 Express Chipset','LGA1151','Support for 9th and 8th Generation Intel® Core™ i9/i7/i5/i3/Pentium®/Celeron® processors',4,'DDR4',128,'4266/4133/4000/3866/3800/3733/3666/3600/3466/3400/3333/3300/3200/3000/2800','2666/2400/2133','1 x HDMI port, supporting a maximum resolution of 4096x2160@30 Hz','1 x PCI Express x16 (running at x16), 1 x PCI Express x16 (running at x4), 4 x PCI Express x1','2 x M.2 connectors (Socket 3, M key), 6 x SATA 6Gb/s connectors','RAID 0, RAID 1, RAID 5, and RAID 10','Realtek® ALC892 codec','Intel® GbE LAN chip (10/100/1000 Mbit)',NULL,'1 x USB 3.1 Gen 2 Type-A, 5 x USB 3.1 Gen 1, 2 x USB 2.0/1.1','2 x USB 3.1 Gen 1, 2 x USB 2.0/1.1 (via internal headers)','1x24-pin ATX main, 1x8-pin ATX 12V, 1x4-pin ATX 12V, 1xCPU fan, 3xsystem fan, 1xRGB LED strip, 6xSATA, 2xM.2, 1xfront panel, 1xfront audio, 1xS/PDIF Out, 1xUSB 3.1 Gen 1, 1xUSB 2.0/1.1, 1xTPM, 1xThunderbolt add-in, 1xserial port, 1xClear CMOS','ATX','30.5cm x 22.5cm','Support for Windows 10 64-bit',12);
/*!40000 ALTER TABLE `motherboard_specs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `psu_specs`
--

DROP TABLE IF EXISTS `psu_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `psu_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(100) NOT NULL,
  `series` varchar(100) DEFAULT NULL,
  `model` varchar(100) NOT NULL,
  `part_number` varchar(100) NOT NULL,
  `wattage` int(10) unsigned NOT NULL,
  `efficiency_rating` varchar(50) DEFAULT NULL COMMENT 'e.g., 80 PLUS Gold, 80 PLUS Platinum',
  `form_factor` varchar(50) NOT NULL,
  `modularity` varchar(50) DEFAULT NULL COMMENT 'e.g., Fully Modular, Semi-Modular, Non-Modular',
  `fan_size_mm` smallint(5) unsigned DEFAULT NULL,
  `fan_bearing_type` varchar(100) DEFAULT NULL,
  `zero_rpm_mode` tinyint(1) DEFAULT 0,
  `atx_connectors_24pin` tinyint(3) unsigned DEFAULT 0,
  `eps_atx12v_connectors_8pin` tinyint(3) unsigned DEFAULT 0 COMMENT 'Typically 4+4 pin',
  `pcie_connectors_8pin` tinyint(3) unsigned DEFAULT 0 COMMENT 'Typically 6+2 pin',
  `sata_connectors` tinyint(3) unsigned DEFAULT 0,
  `pata_connectors_4pin` tinyint(3) unsigned DEFAULT 0 COMMENT 'Also known as Molex',
  `cable_list` text DEFAULT NULL COMMENT 'A list of all included cables and their quantities',
  `dimensions` varchar(100) DEFAULT NULL COMMENT 'Format: L x W x H mm',
  `warranty_years` tinyint(3) unsigned DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `part_number_uniq` (`part_number`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `psu_specs`
--

LOCK TABLES `psu_specs` WRITE;
/*!40000 ALTER TABLE `psu_specs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `psu_specs` (`id`, `manufacturer`, `series`, `model`, `part_number`, `wattage`, `efficiency_rating`, `form_factor`, `modularity`, `fan_size_mm`, `fan_bearing_type`, `zero_rpm_mode`, `atx_connectors_24pin`, `eps_atx12v_connectors_8pin`, `pcie_connectors_8pin`, `sata_connectors`, `pata_connectors_4pin`, `cable_list`, `dimensions`, `warranty_years`, `stock_quantity`) VALUES (1,'Corsair','RMe Series','RM750e','CP-9020248-EU',750,'80 PLUS Gold','ATX','Fully Modular',120,'Rifle Bearing',1,1,2,3,7,4,'1x ATX 24-PIN, 2x EPS/ATX12V 8-PIN (4+4), 3x PCIe 8-PIN (6+2), 7x SATA, 4x PATA','140mm x 150mm x 86mm',7,12);
/*!40000 ALTER TABLE `psu_specs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ram_specs`
--

DROP TABLE IF EXISTS `ram_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ram_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(100) NOT NULL,
  `series_name` varchar(100) DEFAULT NULL,
  `model_number_1` varchar(255) NOT NULL COMMENT 'Primary model or part number',
  `model_number_2` varchar(255) DEFAULT NULL COMMENT 'Secondary model or part number, if applicable',
  `memory_type` varchar(20) NOT NULL COMMENT 'e.g., DDR5, DDR4',
  `capacity_gb` smallint(5) unsigned NOT NULL COMMENT 'Total capacity of the kit in GB',
  `kit_configuration` varchar(50) DEFAULT NULL COMMENT 'e.g., 16GBx2, 8GBx1, 8GBx4',
  `is_dual_channel_kit` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'TRUE if sold as a dual-channel kit',
  `oc_profile_support` varchar(255) DEFAULT NULL COMMENT 'e.g., Intel XMP 3.0, AMD EXPO',
  `tested_speed_mts` int(10) unsigned DEFAULT NULL COMMENT 'Tested speed in MT/s for XMP/EXPO',
  `tested_latency` varchar(50) DEFAULT NULL COMMENT 'Tested CAS latencies, e.g., 36-36-36-83',
  `tested_voltage_v` decimal(3,2) DEFAULT NULL COMMENT 'Tested voltage for XMP/EXPO, e.g., 1.20',
  `spd_speed_mts` int(10) unsigned DEFAULT NULL COMMENT 'Default SPD speed in MT/s',
  `spd_voltage_v` decimal(3,2) DEFAULT NULL COMMENT 'Default SPD voltage, e.g., 1.10',
  `registered_unbuffered` varchar(20) DEFAULT NULL COMMENT 'e.g., Unbuffered, Registered',
  `error_checking` varchar(20) DEFAULT NULL COMMENT 'e.g., Non-ECC, ECC',
  `fan_included` tinyint(1) DEFAULT 0,
  `warranty` varchar(100) DEFAULT NULL COMMENT 'e.g., Limited Lifetime',
  `features` text DEFAULT NULL COMMENT 'Additional features or notes',
  `color` varchar(50) DEFAULT NULL COMMENT 'Color of the heatspreader, if applicable',
  `module_height_mm` decimal(5,2) DEFAULT NULL COMMENT 'Height of the memory module in mm',
  `stock_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ram_specs`
--

LOCK TABLES `ram_specs` WRITE;
/*!40000 ALTER TABLE `ram_specs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ram_specs` (`id`, `manufacturer`, `series_name`, `model_number_1`, `model_number_2`, `memory_type`, `capacity_gb`, `kit_configuration`, `is_dual_channel_kit`, `oc_profile_support`, `tested_speed_mts`, `tested_latency`, `tested_voltage_v`, `spd_speed_mts`, `spd_voltage_v`, `registered_unbuffered`, `error_checking`, `fan_included`, `warranty`, `features`, `color`, `module_height_mm`, `stock_quantity`) VALUES (1,'G.SKILL','Ripjaws S5','F5-5200J3636C16GX2-RS5K','F5-5200J3636C16GA2-RS5K','DDR5',32,'16GBx2',1,'Intel XMP 3.0 / AMD EXPO',5200,'36-36-36-83',1.20,4800,1.10,'Unbuffered','Non-ECC',0,'Limited Lifetime','Ripjaws S5 is a performance DDR5 DRAM memory series made with hand-screened memory ICs that passed G.SKILL rigorous validation tests. Intel XMP 3.0 & AMD EXPO Profile Ready.','Matte Black / Matte White',33.00,12),
(2,'G.SKILL','Ripjaws V','F4-3200C16D-32GVK',NULL,'DDR4',32,'16GBx2',1,'Intel XMP 2.0',3200,'16-18-18-38',1.35,2133,1.20,'Unbuffered','Non-ECC',0,'Limited Lifetime','Intel XMP 2.0 (Extreme Memory Profile) Ready','Black',42.00,12);
/*!40000 ALTER TABLE `ram_specs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `ssd_specs`
--

DROP TABLE IF EXISTS `ssd_specs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ssd_specs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `manufacturer` varchar(100) NOT NULL,
  `series` varchar(100) NOT NULL,
  `model_number` varchar(255) NOT NULL,
  `capacity_gb` int(10) unsigned NOT NULL,
  `form_factor` varchar(50) NOT NULL,
  `interface` varchar(100) NOT NULL,
  `nand_type` varchar(50) DEFAULT NULL,
  `controller` varchar(100) DEFAULT NULL,
  `sequential_read_mbps` int(10) unsigned DEFAULT NULL,
  `sequential_write_mbps` int(10) unsigned DEFAULT NULL,
  `endurance_tbw` int(10) unsigned DEFAULT NULL COMMENT 'Terabytes Written',
  `warranty_years` tinyint(3) unsigned DEFAULT NULL,
  `inventory` varchar(255) DEFAULT NULL,
  `stock_quantity` int(11) DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `model_number_uniq` (`model_number`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ssd_specs`
--

LOCK TABLES `ssd_specs` WRITE;
/*!40000 ALTER TABLE `ssd_specs` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `ssd_specs` (`id`, `manufacturer`, `series`, `model_number`, `capacity_gb`, `form_factor`, `interface`, `nand_type`, `controller`, `sequential_read_mbps`, `sequential_write_mbps`, `endurance_tbw`, `warranty_years`, `inventory`, `stock_quantity`) VALUES (1,'Crucial','P3 Plus','CT500P3PSSD8',500,'M.2 (2280)','NVMe (PCIe Gen 4 x4)','3D-QLC 176-layer','Phison PS5021-E21T',4700,1900,110,5,NULL,12),
(2,'Crucial','P3 Plus','CT1000P3PSSD8',1000,'M.2 (2280)','NVMe (PCIe Gen 4 x4)','3D-QLC 176-layer','Phison PS5021-E21T',5000,3600,220,5,NULL,12),
(3,'Crucial','P3 Plus','CT2000P3PSSD8',2000,'M.2 (2280)','NVMe (PCIe Gen 4 x4)','3D-QLC 176-layer','Phison PS5021-E21T',5000,4200,440,5,NULL,12),
(4,'Crucial','P3 Plus','CT4000P3PSSD8',4000,'M.2 (2280)','NVMe (PCIe Gen 4 x4)','3D-QLC 176-layer','Phison PS5021-E21T',4800,4100,800,5,NULL,12);
/*!40000 ALTER TABLE `ssd_specs` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'master_specs_db'
--

--
-- Dumping routines for database 'master_specs_db'
--
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `AddInventoryColumnToTables` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`lechibang`@`localhost` PROCEDURE `AddInventoryColumnToTables`(IN db_name VARCHAR(64))
BEGIN
    -- Variables to hold table name from the loop and a flag to end the loop
    DECLARE done INT DEFAULT FALSE;
    DECLARE current_table_name VARCHAR(255);
    DECLARE column_count INT;

    -- Declare the cursor to get all table names from the specified database
    DECLARE table_cursor CURSOR FOR
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = db_name AND table_type = 'BASE TABLE';

    -- Declare a handler to set 'done' to true when the cursor has no more rows
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Open the cursor to start fetching
    OPEN table_cursor;

    table_loop: LOOP
        -- Fetch the next table name into our variable
        FETCH table_cursor INTO current_table_name;

        -- If 'done' is true, it means we've processed all tables, so we leave the loop
        IF done THEN
            LEAVE table_loop;
        END IF;

        -- Check if the 'inventory' column exists in the current table
        -- Note: We use PREPARE for dynamic SQL to safely include the table name
        SET @sql_check = CONCAT(
            'SELECT COUNT(*) INTO @col_count FROM information_schema.columns ',
            'WHERE table_schema = ? AND table_name = ? AND column_name = ''inventory'''
        );

        PREPARE stmt_check FROM @sql_check;
        EXECUTE stmt_check USING db_name, current_table_name;
        DEALLOCATE PREPARE stmt_check;

        -- If the column count is 0, the column does not exist, so we add it
        IF @col_count = 0 THEN
            -- Prepare the ALTER TABLE statement
            SET @sql_alter = CONCAT('ALTER TABLE `', db_name, '`.`', current_table_name, '` ADD COLUMN inventory INTEGER DEFAULT 0');

            PREPARE stmt_alter FROM @sql_alter;
            EXECUTE stmt_alter;
            DEALLOCATE PREPARE stmt_alter;
        END IF;

    END LOOP;

    -- Close the cursor to free up resources
    CLOSE table_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `DropColumnFromAllTables` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`lechibang`@`localhost` PROCEDURE `DropColumnFromAllTables`(IN db_name VARCHAR(255), IN col_name VARCHAR(255))
BEGIN
    DECLARE done INT DEFAULT FALSE;
    DECLARE table_n VARCHAR(255);
    DECLARE cur CURSOR FOR
        SELECT table_name
        FROM information_schema.columns
        WHERE table_schema = db_name AND column_name = col_name;
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    OPEN cur;

    read_loop: LOOP
        FETCH cur INTO table_n;
        IF done THEN
            LEAVE read_loop;
        END IF;

        SET @sql = CONCAT('ALTER TABLE `', db_name, '`.`', table_n, '` DROP COLUMN `', col_name, '`');
        PREPARE stmt FROM @sql;
        EXECUTE stmt;
        DEALLOCATE PREPARE stmt;
    END LOOP;

    CLOSE cur;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'IGNORE_SPACE,STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
/*!50003 DROP PROCEDURE IF EXISTS `UpdateAllInventory` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_unicode_ci */ ;
DELIMITER ;;
CREATE DEFINER=`lechibang`@`localhost` PROCEDURE `UpdateAllInventory`(IN db_name VARCHAR(64), IN amount_to_add INT)
BEGIN
    -- Variables to hold the table name and a flag to end the loop
    DECLARE done INT DEFAULT FALSE;
    DECLARE current_table_name VARCHAR(255);

    -- Declare a cursor that selects ONLY the tables in the DB that have an 'inventory' column.
    -- This is more efficient and prevents errors.
    DECLARE table_cursor CURSOR FOR
        SELECT table_name
        FROM information_schema.columns
        WHERE table_schema = db_name AND column_name = 'inventory';

    -- Declare a handler to set 'done' when the cursor runs out of tables
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

    -- Open the cursor
    OPEN table_cursor;

    table_loop: LOOP
        -- Get the next table name
        FETCH table_cursor INTO current_table_name;

        -- If no more tables, exit the loop
        IF done THEN
            LEAVE table_loop;
        END IF;

        -- Construct the dynamic UPDATE statement using a prepared statement.
        -- Using '?' as a placeholder for the value is safer.
        SET @sql_update = CONCAT('UPDATE `', db_name, '`.`', current_table_name, '` SET inventory = inventory + ?');

        -- Prepare, execute, and deallocate the statement
        PREPARE stmt FROM @sql_update;
        EXECUTE stmt USING amount_to_add;
        DEALLOCATE PREPARE stmt;

    END LOOP;

    -- Close the cursor to free up memory
    CLOSE table_cursor;
END ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Current Database: `suppliers_db`
--

/*!40000 DROP DATABASE IF EXISTS `suppliers_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `suppliers_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `suppliers_db`;

--
-- Table structure for table `suppliers`
--

DROP TABLE IF EXISTS `suppliers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `suppliers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `category` varchar(100) DEFAULT NULL,
  `contact_person` varchar(255) DEFAULT NULL,
  `contact_position` varchar(255) DEFAULT NULL,
  `contact_email` varchar(255) DEFAULT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(50) DEFAULT NULL,
  `website` varchar(255) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='Stores main supplier company details';
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `suppliers`
--

LOCK TABLES `suppliers` WRITE;
/*!40000 ALTER TABLE `suppliers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `suppliers` (`id`, `name`, `category`, `contact_person`, `contact_position`, `contact_email`, `email`, `phone`, `website`, `address`, `notes`, `is_active`, `created_at`) VALUES (1,'TechCorp Solutions',NULL,'John Smith',NULL,NULL,'john@techcorp.com','+1-555-0101',NULL,'123 Tech Street, Silicon Valley, CA 94000',NULL,1,'2025-06-14 12:39:04'),
(2,'Industrial Parts Ltd',NULL,'Sarah Johnson',NULL,NULL,'sarah@industrialparts.com','+1-555-0102',NULL,'456 Industry Blvd, Detroit, MI 48000',NULL,1,'2025-06-14 12:39:04'),
(3,'Global Electronics',NULL,'Mike Chen',NULL,NULL,'mike@globalelectronics.com','+1-555-0103',NULL,'789 Electronics Ave, Austin, TX 73000',NULL,1,'2025-06-14 12:39:04'),
(4,'Precision Tools Inc',NULL,'Lisa Rodriguez',NULL,NULL,'lisa@precisiontools.com','+1-555-0104',NULL,'321 Tools Drive, Cleveland, OH 44000',NULL,1,'2025-06-14 12:39:04'),
(5,'Green Supply Co',NULL,'David Wilson',NULL,NULL,'david@greensupply.com','+1-555-0105',NULL,'654 Green Lane, Portland, OR 97000',NULL,1,'2025-06-14 12:39:04'),
(6,'Quality Materials',NULL,'Emma Thompson',NULL,NULL,'emma@qualitymaterials.com','+1-555-0106',NULL,'987 Quality Road, Denver, CO 80000',NULL,0,'2025-06-14 12:39:04'),
(7,'Fast Logistics',NULL,'Robert Brown',NULL,NULL,'robert@fastlogistics.com','+1-555-0107',NULL,'147 Speed Highway, Phoenix, AZ 85000',NULL,1,'2025-06-14 12:39:04'),
(8,'Reliable Components',NULL,'Jennifer Davis',NULL,NULL,'jennifer@reliablecomponents.com','+1-555-0108',NULL,'258 Reliable Street, Seattle, WA 98000',NULL,1,'2025-06-14 12:39:04'),
(49,'Apex Tech Solutions','CPU, GPU, Motherboard, RAM, PSU, Case, Cooling, Storage','An Nguyen','Sales Director','an.nguyen@apextech.vn','sales@apextech.vn','0901234567','https://apextech.vn','15 Tran Hung Dao, Hoan Kiem, Hanoi','Primary distributor for major brands. Bulk discounts available.',0,'2024-05-20 03:00:00'),
(50,'Global Chip Distribution','CPU, GPU, RAM, Storage','John Smith','Global Accounts','j.smith@globalchip.com','contact@globalchip.com','+1-408-555-0101','https://globalchip.com','2100 Logic Lane, San Jose, CA, USA','International supplier, handles large B2B orders only. Minimum order $10,000.',1,'2023-11-10 07:20:00'),
(51,'Hanoi Computer World','CPU, GPU, Motherboard, RAM, PSU, Case, Cooling, Storage, Peripherals','Tran Van Bach','Store Manager','bach.tv@hanoicw.com.vn','support@hanoicw.com.vn','0988123123','https://hanoicw.com.vn','55 Thai Ha, Dong Da, Hanoi','Leading local retailer for all PC components and peripherals.',1,'2024-01-15 02:30:00'),
(52,'PC Parts Pro','Motherboard, RAM, PSU, Case','Emily Carter','B2B Manager','emily.c@pcpartspro.net','sales@pcpartspro.net','0977654321','https://pcpartspro.net','789 Component Ave, Industry City','Focuses on core components for system builders.',1,'2024-02-28 04:00:00'),
(53,'Saigon Tech Hub','GPU, RAM, Storage, Peripherals','Le Thi Mai','Sales Representative','mai.le@saigontech.vn','info@saigontech.vn','0915888999','https://saigontech.vn','101 Nguyen Hue, District 1, Ho Chi Minh City','Strong focus on gaming components and high-end peripherals.',1,'2024-03-12 09:45:00'),
(54,'CPU Core','CPU','Michael Chen','Sourcing Specialist','m.chen@cpucore.io','sourcing@cpucore.io','+886-2-5555-0188','https://cpucore.io','Hsinchu Science Park, Hsinchu, Taiwan','Specializes in bulk trays of Intel and AMD CPUs.',1,'2024-06-05 11:00:00'),
(55,'GPU Kings','GPU','David Lee','Product Manager','david.l@gpukings.com','support@gpukings.com','0905111222','https://gpukings.com','Akihabara, Tokyo, Japan','Imports and distributes high-end and rare GPUs.',1,'2023-10-03 05:10:00'),
(56,'Board Builders Inc.','Motherboard','Sophia Rodriguez','Lead Engineer','sophia.r@boardbuilders.com','tech@boardbuilders.com','+1-512-555-0155','https://boardbuilders.com','Austin, TX, USA','OEM manufacturer of custom motherboards. No retail.',1,'2024-04-19 08:00:00'),
(57,'Memory Module Masters','RAM','Ben Carter','Sales Rep','ben@memmasters.net','sales@memmasters.net','0933445566','https://memmasters.net','Shenzhen, Guangdong, China','High-volume RAM module supplier.',1,'2023-08-25 02:55:00'),
(58,'VoltVault Power','PSU','Frank Miller','Quality Assurance','frank.m@voltvault.com','qa@voltvault.com','0987000111','https://voltvault.com','Hamburg, Germany','Supplier of high-efficiency, certified power supply units.',1,'2024-05-01 06:30:00'),
(59,'Chassis Crafters','Case','Chloe Garcia','Designer','chloe.g@chassiscrafters.dev','info@chassiscrafters.dev','0911223344','https://chassiscrafters.dev','Los Angeles, CA, USA','Boutique PC case designer and manufacturer.',1,'2024-07-01 04:15:00'),
(60,'Arctic Airflow','Cooling','Olaf Gustafsson','R&D Head','olaf.g@arcticairflow.se','contact@arcticairflow.se','+46-8-555-0123','https://arcticairflow.se','Stockholm, Sweden','Specializes in high-performance CPU coolers and case fans.',1,'2023-09-14 03:40:00'),
(61,'DataDrive Direct','Storage','Kenji Tanaka','Director of Ops','k.tanaka@datadrive.jp','orders@datadrive.jp','+81-3-5555-0199','https://datadrive.jp','Shibuya, Tokyo, Japan','Wholesale supplier of SSDs and NVMe drives.',1,'2024-02-17 12:00:00'),
(62,'Ergo-Clicks','Peripherals','Laura Schmidt','Marketing','laura.s@ergo-clicks.de','info@ergo-clicks.de','0955667788','https://ergo-clicks.de','Berlin, Germany','Focus on ergonomic mice and keyboards.',1,'2023-12-22 09:20:00'),
(63,'Visionary Displays','Monitors','Rachel Adams','Sales Executive','r.adams@visionary.com','sales@visionary.com','0922334455','https://visionary.com','Seoul, South Korea','Supplier of professional-grade 4K and OLED monitors.',1,'2024-06-11 07:00:00'),
(64,'Danang IT Surplus','RAM, Storage, Used GPUs','Pham Van Dong','Owner','dong.pham@danangit.vn','contact@danangit.vn','0944556677','https://danangit.vn','3 Le Duan, Hai Chau, Da Nang','Sells new old stock and tested used components.',1,'2023-05-30 10:10:00'),
(65,'Power & Case Co.','PSU, Case','Robert Brown','Partner','rob.b@powercase.com','info@powercase.com','0966778899','https://powercase.com','Manchester, UK','Small supplier focusing on budget builds.',1,'2024-08-01 03:00:00'),
(66,'Old Components Ltd.','Motherboard, RAM','N/A','N/A','contact-1@old-components.example.com','main-1@old-components.example.com','N/A','N/A','N/A','Ceased trading in 2023. Do not contact.',0,'2021-04-11 17:00:00'),
(67,'Connector King','Cables, Adapters','Henry Wu','Manager','henry.w@connectorking.net','orders@connectorking.net','0988990011','https://connectorking.net','Guangzhou, China','Sells all types of internal and external PC cables.',1,'2023-07-20 04:30:00'),
(68,'Defunct Devices','CPU, GPU','N/A','N/A','contact-2@defunct-devices.example.com','main-2@defunct-devices.example.com','N/A','N/A','N/A','Went into administration. All assets sold.',0,'2022-10-04 17:00:00');
/*!40000 ALTER TABLE `suppliers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'suppliers_db'
--

--
-- Dumping routines for database 'suppliers_db'
--

--
-- Current Database: `orders_db`
--

/*!40000 DROP DATABASE IF EXISTS `orders_db`*/;

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `orders_db` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci */;

USE `orders_db`;

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `customers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `company` varchar(255) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `is_active` tinyint(1) DEFAULT 1,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `idx_name` (`name`),
  KEY `idx_email` (`email`),
  KEY `idx_is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customers`
--

LOCK TABLES `customers` WRITE;
/*!40000 ALTER TABLE `customers` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `address`, `company`, `notes`, `is_active`, `created_at`, `updated_at`) VALUES (1,'John Doe','john.doe@email.com','+1-555-0101','123 Main St, Anytown, USA','TechCorp','Regular customer',1,'2025-06-15 04:03:10','2025-06-15 04:03:10'),
(2,'Jane Smith','jane.smith@email.com','+1-555-0102','456 Oak Ave, Somewhere, USA','DataSys Inc','Corporate client',1,'2025-06-15 04:03:10','2025-06-15 04:03:10'),
(3,'Mike Johnson','mike.johnson@email.com','+1-555-0103','789 Pine Rd, Elsewhere, USA',NULL,'Individual buyer',1,'2025-06-15 04:03:10','2025-06-15 04:03:10'),
(4,'Sarah Wilson','sarah.wilson@email.com','+1-555-0104','321 Elm St, Nowhere, USA','StartupTech','New customer',1,'2025-06-15 04:03:10','2025-06-15 04:03:10'),
(5,'David Brown','david.brown@email.com','+1-555-0105','654 Maple Dr, Anyplace, USA',NULL,'Gaming enthusiast',1,'2025-06-15 04:03:10','2025-06-15 04:03:10');
/*!40000 ALTER TABLE `customers` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `purchase_order_items`
--

DROP TABLE IF EXISTS `purchase_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_order_id` int(11) NOT NULL,
  `item_table` varchar(100) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `received_quantity` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_purchase_order_id` (`purchase_order_id`),
  KEY `idx_item_table_id` (`item_table`,`item_id`),
  CONSTRAINT `purchase_order_items_ibfk_1` FOREIGN KEY (`purchase_order_id`) REFERENCES `purchase_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_order_items`
--

LOCK TABLES `purchase_order_items` WRITE;
/*!40000 ALTER TABLE `purchase_order_items` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `purchase_order_items` (`id`, `purchase_order_id`, `item_table`, `item_id`, `item_name`, `quantity`, `unit_price`, `total_price`, `received_quantity`, `created_at`) VALUES (1,3,'cpu_specs',1,'Intel i7-12700K',5,350.00,1750.00,5,'2025-06-15 04:10:05'),
(2,3,'cpu_specs',2,'Intel i7-8700',3,280.00,840.00,3,'2025-06-15 04:10:05');
/*!40000 ALTER TABLE `purchase_order_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lechibang`@`localhost`*/ /*!50003 TRIGGER update_po_total_after_insert
AFTER INSERT ON purchase_order_items
FOR EACH ROW
BEGIN
    UPDATE purchase_orders 
    SET subtotal = (
        SELECT COALESCE(SUM(total_price), 0) 
        FROM purchase_order_items 
        WHERE purchase_order_id = NEW.purchase_order_id
    ),
    total_amount = subtotal + tax_amount + shipping_cost
    WHERE id = NEW.purchase_order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lechibang`@`localhost`*/ /*!50003 TRIGGER update_po_total_after_update
AFTER UPDATE ON purchase_order_items
FOR EACH ROW
BEGIN
    UPDATE purchase_orders 
    SET subtotal = (
        SELECT COALESCE(SUM(total_price), 0) 
        FROM purchase_order_items 
        WHERE purchase_order_id = NEW.purchase_order_id
    ),
    total_amount = subtotal + tax_amount + shipping_cost
    WHERE id = NEW.purchase_order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lechibang`@`localhost`*/ /*!50003 TRIGGER update_po_total_after_delete
AFTER DELETE ON purchase_order_items
FOR EACH ROW
BEGIN
    UPDATE purchase_orders 
    SET subtotal = (
        SELECT COALESCE(SUM(total_price), 0) 
        FROM purchase_order_items 
        WHERE purchase_order_id = OLD.purchase_order_id
    ),
    total_amount = subtotal + tax_amount + shipping_cost
    WHERE id = OLD.purchase_order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `purchase_orders`
--

DROP TABLE IF EXISTS `purchase_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `po_number` varchar(50) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `status` enum('Draft','Ordered','Shipped','Received','Cancelled') DEFAULT 'Draft',
  `order_date` date NOT NULL,
  `expected_delivery_date` date DEFAULT NULL,
  `actual_delivery_date` date DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `shipping_cost` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) DEFAULT 0.00,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `po_number` (`po_number`),
  KEY `idx_po_number` (`po_number`),
  KEY `idx_supplier_id` (`supplier_id`),
  KEY `idx_status` (`status`),
  KEY `idx_order_date` (`order_date`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase_orders`
--

LOCK TABLES `purchase_orders` WRITE;
/*!40000 ALTER TABLE `purchase_orders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `purchase_orders` (`id`, `po_number`, `supplier_id`, `status`, `order_date`, `expected_delivery_date`, `actual_delivery_date`, `subtotal`, `tax_amount`, `shipping_cost`, `total_amount`, `notes`, `created_at`, `updated_at`) VALUES (1,'PO-2025-001',1,'Ordered','2025-06-10','2025-06-20',NULL,2500.00,200.00,0.00,2700.00,'Initial stock order','2025-06-15 04:03:10','2025-06-15 04:03:10'),
(2,'PO-2025-002',2,'Shipped','2025-06-12','2025-06-22',NULL,1800.00,144.00,0.00,1944.00,'AMD processors','2025-06-15 04:03:10','2025-06-15 04:03:10'),
(3,'PO-2025-003',3,'Received','2025-06-08','2025-06-18',NULL,2590.00,256.00,0.00,2846.00,'Motherboard restock','2025-06-15 04:03:10','2025-06-15 04:10:05');
/*!40000 ALTER TABLE `purchase_orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Table structure for table `sales_order_items`
--

DROP TABLE IF EXISTS `sales_order_items`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_order_items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_order_id` int(11) NOT NULL,
  `item_table` varchar(100) NOT NULL,
  `item_id` int(11) NOT NULL,
  `item_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `shipped_quantity` int(11) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `idx_sales_order_id` (`sales_order_id`),
  KEY `idx_item_table_id` (`item_table`,`item_id`),
  CONSTRAINT `sales_order_items_ibfk_1` FOREIGN KEY (`sales_order_id`) REFERENCES `sales_orders` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_order_items`
--

LOCK TABLES `sales_order_items` WRITE;
/*!40000 ALTER TABLE `sales_order_items` DISABLE KEYS */;
set autocommit=0;
/*!40000 ALTER TABLE `sales_order_items` ENABLE KEYS */;
UNLOCK TABLES;
commit;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lechibang`@`localhost`*/ /*!50003 TRIGGER update_so_total_after_insert
AFTER INSERT ON sales_order_items
FOR EACH ROW
BEGIN
    UPDATE sales_orders 
    SET subtotal = (
        SELECT COALESCE(SUM(total_price), 0) 
        FROM sales_order_items 
        WHERE sales_order_id = NEW.sales_order_id
    ),
    total_amount = subtotal + tax_amount + shipping_cost
    WHERE id = NEW.sales_order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lechibang`@`localhost`*/ /*!50003 TRIGGER update_so_total_after_update
AFTER UPDATE ON sales_order_items
FOR EACH ROW
BEGIN
    UPDATE sales_orders 
    SET subtotal = (
        SELECT COALESCE(SUM(total_price), 0) 
        FROM sales_order_items 
        WHERE sales_order_id = NEW.sales_order_id
    ),
    total_amount = subtotal + tax_amount + shipping_cost
    WHERE id = NEW.sales_order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_uca1400_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,ERROR_FOR_DIVISION_BY_ZERO,NO_AUTO_CREATE_USER,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
/*!50003 CREATE*/ /*!50017 DEFINER=`lechibang`@`localhost`*/ /*!50003 TRIGGER update_so_total_after_delete
AFTER DELETE ON sales_order_items
FOR EACH ROW
BEGIN
    UPDATE sales_orders 
    SET subtotal = (
        SELECT COALESCE(SUM(total_price), 0) 
        FROM sales_order_items 
        WHERE sales_order_id = OLD.sales_order_id
    ),
    total_amount = subtotal + tax_amount + shipping_cost
    WHERE id = OLD.sales_order_id;
END */;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;

--
-- Table structure for table `sales_orders`
--

DROP TABLE IF EXISTS `sales_orders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sales_orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `so_number` varchar(50) NOT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `status` enum('Draft','Confirmed','Processing','Shipped','Delivered','Cancelled') DEFAULT 'Draft',
  `order_date` date NOT NULL,
  `ship_date` date DEFAULT NULL,
  `delivery_date` date DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT 0.00,
  `tax_amount` decimal(10,2) DEFAULT 0.00,
  `shipping_cost` decimal(10,2) DEFAULT 0.00,
  `total_amount` decimal(10,2) DEFAULT 0.00,
  `customer_name` varchar(255) DEFAULT NULL,
  `customer_email` varchar(255) DEFAULT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `so_number` (`so_number`),
  KEY `idx_so_number` (`so_number`),
  KEY `idx_customer_id` (`customer_id`),
  KEY `idx_status` (`status`),
  KEY `idx_order_date` (`order_date`),
  CONSTRAINT `sales_orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sales_orders`
--

LOCK TABLES `sales_orders` WRITE;
/*!40000 ALTER TABLE `sales_orders` DISABLE KEYS */;
set autocommit=0;
INSERT INTO `sales_orders` (`id`, `so_number`, `customer_id`, `status`, `order_date`, `ship_date`, `delivery_date`, `subtotal`, `tax_amount`, `shipping_cost`, `total_amount`, `customer_name`, `customer_email`, `customer_phone`, `shipping_address`, `notes`, `created_at`, `updated_at`) VALUES (1,'SO-2025-001',1,'Confirmed','2025-06-14',NULL,NULL,1500.00,120.00,50.00,1670.00,NULL,NULL,NULL,'123 Main St, Anytown, USA','Gaming PC build','2025-06-15 04:03:10','2025-06-15 04:03:10'),
(2,'SO-2025-002',2,'Processing','2025-06-15',NULL,NULL,2800.00,224.00,0.00,3024.00,NULL,NULL,NULL,'456 Oak Ave, Somewhere, USA','Office workstation','2025-06-15 04:03:10','2025-06-15 04:03:10'),
(3,'SO-2025-003',3,'Draft','2025-06-15',NULL,NULL,800.00,64.00,25.00,889.00,NULL,NULL,NULL,'789 Pine Rd, Elsewhere, USA','Upgrade components','2025-06-15 04:03:10','2025-06-15 04:03:10');
/*!40000 ALTER TABLE `sales_orders` ENABLE KEYS */;
UNLOCK TABLES;
commit;

--
-- Dumping events for database 'orders_db'
--

--
-- Dumping routines for database 'orders_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2025-06-15 13:26:22
